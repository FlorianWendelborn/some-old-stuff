/*net dummy*/

function initNet () {
	console.log('#todo - initNet');
}

function getMap (id) {
	console.log('Could not get map \'' + id + '\'');
}
